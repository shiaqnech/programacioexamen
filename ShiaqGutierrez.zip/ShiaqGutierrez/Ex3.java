/**
 * Ex3
 */
//Per posar amb decimals en comptes de int seria float pero no m'en recordo de com implementarlo al system console readline
public class Ex3 {

    public static void main(String[] args) {
        int nota;
        System.out.println("Usuari introdueix la teva nota");
        nota = Integer.parseInt(System.console().readLine());
        


        if (nota<2){
            System.out.println("Nota: Molt deficient ");
            System.out.println("No t'has mirat res ");
            
        }
        
        else if (nota<5){
            System.out.println("Nota: Insuficient alt ");
            System.out.println("Et falta poc per aprovar ");
            
        }
        else if (nota<6){
            System.out.println("Nota: Suficient");
            System.out.println("Has aprovat però justet. No et confiïs");
            
        }
        else if (nota<8){
            System.out.println("Nota: Notable ");
            System.out.println("La teva evolució es bona ");
            
        }
        else if (nota<=10){
            System.out.println("Nota: Excel·lent ");
            System.out.println("Felicitats arribes a l'Execlència!!");
            
        }
        else if (nota>10){
            System.out.println("Error numero incorrecte");
        }
        


    }
}