/**
 * Ex2
 */
public class Ex2 {

    public static void main(String[] args) {
        
        
        String nom1;
        System.out.println("Usuari 1 introdueix el teu nom");
        nom1 = System.console().readLine();
        int edat1;
        System.out.println("Introdueix la teva edat");
        edat1 = Integer.parseInt(System.console().readLine());                
        String nom2;
        System.out.println("Usuari2 introdueix el teu nom");
        nom2 = System.console().readLine();
        int edat2;
        System.out.println("Introdueix la teva edat");
        edat2 = Integer.parseInt(System.console().readLine());
        int dif; 
        

        if (edat1>edat2){

            dif= (edat1-edat2);

            System.out.println("En "+nom1+" és "+dif+" anys més gran que "+nom2);

        }
        if (edat1<edat2){

            dif= (edat2-edat1);

            System.out.println("En "+nom2+" és "+dif+" anys més gran que "+nom1);

        }

    }
}