/**
 * Ex1
 */
public class Ex1 {

    public static void main(String[] args) {
        int edat;
        System.out.println("Introdueix la teva edat");
        edat = Integer.parseInt(System.console().readLine());
        int esperadanys;
        esperadanys = (18-edat);              

        if (edat>=18) {
            System.out.println("Felicitats ja pots conduir");

                       
        }
        else {
            System.out.println("Encara ets jove. Et resten "+esperadanys+" per poder conduir");
        }
        
    }
}