import java.lang.reflect.Array;

/**
 * Ex4
 */
public class Ex4 {

    public static void main(String[] args) {

        int array1 = new int [10];
        int array2 = new int [100];
        int array3 = new int [1000];

        System.out.println(array1.length());
    }

}