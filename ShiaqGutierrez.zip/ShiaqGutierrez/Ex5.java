import java.util.Random;

/**
 * Ex5
 */
public class Ex5 {

    public static void main(String[] args) {
            
        Random r =new Random();
        int numMaquina = r.nextInt(10);      
        String pregunta1;
        System.out.println("Tria parells(P) o (C)cenars"); 
        pregunta1= System.console().readLine();

        if (pregunta1.equalsIgnoreCase("P")){
            int dits;
            String jugar;
            System.out.println("Quants dits treuras");
            dits = Integer.parseInt(System.console().readLine()); 
            System.out.println("Presiona intro per jugar");
            jugar = System.console().readLine();
            if (jugar.equals("")){
                suma = (dits+numMaquina);
                System.out.println(numMaquina);


            }
            


        }
        else if (pregunta1.equalsIgnoreCase("C"));
            int dits;
            System.out.println("Quants dits treuras");
            dits = Integer.parseInt(System.console().readLine());

    }
}